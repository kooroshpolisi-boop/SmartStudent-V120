#!/usr/bin/env bash
set -euo pipefail
APP_DIR=android/app/src/main
mkdir -p "$APP_DIR/res/values" "$APP_DIR/res/values-fa"
cat > "$APP_DIR/res/values/strings.xml" <<'XML'
<resources><string name="app_name">Planner legend</string></resources>
XML
cat > "$APP_DIR/res/values-fa/strings.xml" <<'XML'
<resources><string name="app_name">برنامه هفتگی پیشرفته</string></resources>
XML
python3 - <<'PY2'
from pathlib import Path
p=Path('android/app/src/main/AndroidManifest.xml')
s=p.read_text(encoding='utf-8')
import re
s=re.sub(r'android:label="[^"]*"', 'android:label="@string/app_name"', s, count=1)
p.write_text(s,encoding='utf-8')
PY2
