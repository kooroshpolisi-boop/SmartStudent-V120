# SmartStudent V120 Android build package

This repository package contains the V20 theme-fixed HTML app as `index.html`, Capacitor Android build configuration, localized Android launcher labels, and a GitHub Actions workflow.

Push the contents of this folder to the repository root on branch `main`. GitHub Actions runs on push or can be started manually from Actions > Build Planner APK > Run workflow.

The APK is uploaded as the `Planner-APK` workflow artifact.
